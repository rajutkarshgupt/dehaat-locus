from django.urls import path

from repayment.views import (
    GetLenderAndInterestRateView,
    IVRNextInstallmentStatus,
    IVRRepaymentOTPView,
    IVRRepaymentStatus,
    ListCreateTransactionView,
    ListFarmersView,
    RetrieveAggregatedAmountView,
    RetrieveFarmerDetailsView,
)

urlpatterns = [
    path("v1/transaction", ListCreateTransactionView.as_view()),
    path("v1/aggregated-amount", RetrieveAggregatedAmountView.as_view()),
    path("v1/farmers", ListFarmersView.as_view()),
    path("v1/farmer/<int:farmer_id>", RetrieveFarmerDetailsView.as_view()),
    path(
        "v1/farmer/<int:farmer_id>/lender-interest",
        GetLenderAndInterestRateView.as_view(),
    ),
    path("v1/ivr-repayment-otp", IVRRepaymentOTPView.as_view()),
    path("v1/ivr/next-installment-status", IVRNextInstallmentStatus.as_view()),
    path("v1/ivr/repayment-status", IVRRepaymentStatus.as_view()),
]
