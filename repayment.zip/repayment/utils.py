import logging
from datetime import date

from django.db.models import Sum

from repayment.models import TRANSACTION_TYPE_CHOICES, DemandSheet, Transaction

LOGGER = logging.getLogger("stdout-logger")


def get_current_demand_data_for_user(user_id):
    current_date = date.today()
    try:
        return DemandSheet.objects.get(
            to_date__gte=current_date, from_date__lte=current_date, user_id=user_id
        )
    except DemandSheet.DoesNotExist:
        LOGGER.info(f"No demand data found for farmer with id: {user_id}")
        return DemandSheet.objects.none()


def get_paid_emi_of_user(user_id):
    current_demand_sheet_data = get_current_demand_data_for_user(user_id)
    if not current_demand_sheet_data:
        return 0
    to_date = current_demand_sheet_data.to_date
    from_date = current_demand_sheet_data.from_date
    collected_amount = (
        Transaction.objects.filter(
            payer=user_id,
            transaction_type=TRANSACTION_TYPE_CHOICES.Collection,
            created_at__lte=to_date,
            created_at__gte=from_date,
        )
        .aggregate(Sum("amount"))
        .get("amount__sum")
    )
    return collected_amount


def get_pending_emi_of_user(user_id):
    collected_amount = get_paid_emi_of_user(user_id) or 0
    demand_data = get_current_demand_data_for_user(user_id)
    net_demand = 0
    if demand_data:
        net_demand = float(demand_data.net_demand_amount)
    return net_demand - float(collected_amount)
