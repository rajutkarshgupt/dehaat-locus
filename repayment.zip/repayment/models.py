import csv
import uuid
from datetime import datetime

from django.core.validators import FileExtensionValidator
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from model_utils import Choices

from base.models import BaseModel

ENTITY_TYPE_CHOICES = Choices("DC", "GROUP LEADER", "FSFE", "FARMER")
TRANSACTION_TYPE_CHOICES = Choices("Collection", "Deposit")
TRANSACTION_CHANNEL_CHOICES = Choices("CSC", "Bank", "Fino", "Cash")


class Transaction(BaseModel):
    transaction_id = models.UUIDField(default=uuid.uuid4, db_index=True)
    payee = models.BigIntegerField(null=True, blank=True)
    payer = models.BigIntegerField()
    payee_type = models.CharField(
        choices=ENTITY_TYPE_CHOICES, max_length=25, null=True, blank=True
    )
    payer_type = models.CharField(choices=ENTITY_TYPE_CHOICES, max_length=25)
    amount = models.DecimalField(decimal_places=2, max_digits=10)
    transaction_type = models.CharField(choices=TRANSACTION_TYPE_CHOICES, max_length=25)
    transaction_channel = models.CharField(
        choices=TRANSACTION_CHANNEL_CHOICES, max_length=25
    )
    meta = models.JSONField(default=list)  # recipt_photo, utrn would be in dict

    def __str__(self):
        return str(self.id)


class DemandSheet(BaseModel):
    to_date = models.DateField()
    from_date = models.DateField()
    due_date = models.DateField()
    dpt = models.IntegerField(null=True)
    user_id = models.BigIntegerField()
    phone_number = models.TextField(null=True, blank=True)
    sanctioned_limit_amount = models.DecimalField(
        decimal_places=2, max_digits=10
    )  # credit limit
    disbursement_amount = models.DecimalField(
        decimal_places=2, max_digits=10
    )  # disbursed till date
    repaid_amount = models.DecimalField(
        decimal_places=2, max_digits=10
    )  # is it for month or till date?
    advance_paid_amount = models.DecimalField(decimal_places=2, max_digits=10)
    outstanding_amount = models.DecimalField(decimal_places=2, max_digits=10)
    cumulative_emi_amount = models.DecimalField(
        decimal_places=2, max_digits=10, default=0
    )
    principal_repayment_amount = models.DecimalField(decimal_places=2, max_digits=10)
    interest_repayment_amount = models.DecimalField(decimal_places=2, max_digits=10)
    processing_fee_repayment_amount = models.DecimalField(
        decimal_places=2, max_digits=10
    )
    overdue_amount = models.DecimalField(decimal_places=2, max_digits=10)
    late_fee_amount = models.DecimalField(decimal_places=2, max_digits=10)
    net_demand_amount = models.DecimalField(decimal_places=2, max_digits=10)

    def __str__(self):
        return str(self.id)


def get_demand_sheet_file_upload_path(instance, filename):
    date = datetime.utcnow()
    return "demand_sheet/{}/{}-{}".format(
        date.date(), int(date.timestamp() * 1000), filename
    )


DEMAND_SHEET_UPLOAD_ACTION_CHOICES = Choices(
    ("Insert_New_Demand_Sheet", "Insert New Demand Sheet"),
    ("Update_Previous_Demand_Sheet", "Update Previous Demand Sheet"),
)


class DemandSheetUpload(BaseModel):
    to_date = models.DateField()
    from_date = models.DateField()
    upload_action = models.TextField(
        choices=DEMAND_SHEET_UPLOAD_ACTION_CHOICES, verbose_name="Upload Action"
    )
    file = models.FileField(
        upload_to=get_demand_sheet_file_upload_path,
        validators=[FileExtensionValidator(allowed_extensions=["csv"])],
        verbose_name="Upload Demand Sheet in CSV format",
    )


@receiver(post_save, sender=DemandSheetUpload)
def on_demand_sheet_upload(sender, instance, *args, **kwargs):
    from repayment.tasks import (
        insert_demand_sheet_details,
        update_previous_demand_details,
    )

    if kwargs.get("created"):
        to_date = instance.to_date
        from_date = instance.from_date
        with instance.file.open(mode="r") as file:
            reader = csv.reader(file)
            next(reader)
            if (
                instance.upload_action
                == DEMAND_SHEET_UPLOAD_ACTION_CHOICES.Insert_New_Demand_Sheet
            ):
                for row in reader:
                    insert_demand_sheet_details.delay(row, to_date, from_date)
            elif (
                instance.upload_action
                == DEMAND_SHEET_UPLOAD_ACTION_CHOICES.Update_Previous_Demand_Sheet
            ):
                for row in reader:
                    update_previous_demand_details.delay(row, to_date, from_date)
