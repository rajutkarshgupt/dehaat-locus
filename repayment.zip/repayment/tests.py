import json
from unittest.mock import patch

from rest_framework import status
from rest_framework.test import APITestCase

from common.constants import Constants, TestConstants
from repayment.models import TRANSACTION_TYPE_CHOICES


@patch(
    "common.utils.KhetiDB.get_record_for_given_table_and_id",
    return_value=Constants.get_agent_details_patch,
)
@patch(
    "common.external.kheti.Kheti.get_self_user_details",
    return_value=Constants.get_agent_details_patch,
)
class TestListCreateTransactionView(APITestCase):
    fixtures = ["transaction", "demand_sheet"]
    url = "/repayment/v1/transaction?transaction_type={}"

    def test_get_queryset_collection(self, *args, **kwargs):
        transaction_type = TRANSACTION_TYPE_CHOICES.Collection
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url.format(transaction_type))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data.get("results", {})[0].get("payee"), 180868)
        self.assertEqual(response.data.get("results", {})[0].get("amount"), 1000)

    def test_get_queryset_deposit(self, *args, **kwargs):
        transaction_type = TRANSACTION_TYPE_CHOICES.Deposit
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url.format(transaction_type))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            response.data.get("results", {})[0].get("payer").get("id"), 180868
        )
        self.assertEqual(response.data.get("results", {})[0].get("amount"), 1000)

    url2 = "/repayment/v1/transaction?transaction_type={}&type={}"

    def test_get_queryset_type(self, *args, **kwargs):

        type = {
            "transaction_date_lte": "2022-07-14",
            "transaction_date_gte": "2022-07-14",
        }
        type = json.dumps(type)
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url2.format(type))
        self.assertEqual(response.status_code, status.HTTP_200_OK)


@patch(
    "common.utils.KhetiDB.get_record_for_given_table_and_id",
    return_value=Constants.get_agent_details_patch,
)
@patch(
    "common.external.kheti.Kheti.get_self_user_details",
    return_value=Constants.get_agent_details_patch,
)
class TestRetrieveAggregatedAmountView(APITestCase):
    fixtures = ["transaction", "demand_sheet"]
    url = "/repayment/v1/aggregated-amount"

    def test_retrieve(self, *args, **kwargs):
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)


@patch(
    "common.utils.KhetiDB.get_record_for_given_table_and_id",
    return_value=Constants.get_agent_details_patch,
)
@patch(
    "common.external.kheti.Kheti.get_self_user_details",
    return_value=Constants.get_agent_details_patch,
)
class TestListFarmersView(APITestCase):
    fixtures = ["transaction", "demand_sheet"]
    url = "/repayment/v1/farmers?keyword={}"

    def test_list_by_name(self, request, *args, **kwargs):
        keyword = "Utkarsh"
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url.format(keyword))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_by_number(self, *args, **kwargs):
        keyword = "914015378"
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url.format(keyword))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    url2 = "/repayment/v1/farmers?list_type={}"

    def test_list_by_overdue(self, *args, **kwargs):
        list_type = "overdue"
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url2.format(list_type))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_by_to_be_collected(self, *args, **kwargs):
        list_type = "to_be_collected"
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url2.format(list_type))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    url3 = "/repayment/v1/farmers?type={}"

    def test_list_by_dc(self, *args, **kwargs):
        type = {"dehaat_centers": [1]}
        type = json.dumps(type)
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url3.format(type))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_by_village(self, *args, **kwargs):
        type = {"location": [1]}
        type = json.dumps(type)
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url3.format(type))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_by_gl(self, *args, **kwargs):
        type = {"group_leader": [180781]}
        type = json.dumps(type)
        self.client.credentials(**TestConstants.HEADERS)
        response = self.client.get(self.url3.format(type))
        self.assertEqual(response.status_code, status.HTTP_200_OK)


@patch(
    "common.utils.KhetiDB.get_record_for_given_table_and_id",
    return_value=Constants.get_record_for_given_table_and_id_patch,
)
@patch(
    "common.external.kheti.Kheti.get_self_user_details",
    return_value=Constants.user_with_application_patch,
)
class TestRetrieveFarmerDetailsView(APITestCase):
    fixtures = ["transaction", "demand_sheet", "user_application"]
    url = "/repayment/v1/farmer/{}"

    def test_get_specific_farmer(self, *args, **kwargs):
        self.client.credentials(**TestConstants.HEADERS_FARMER)
        response = self.client.get(self.url.format(2), format="json")
        self.assertEqual(response.data.get("user")["id"], 2)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_get_non_existing_farmer(self, *args, **kwargs):
        self.client.credentials(**TestConstants.HEADERS_FARMER)
        response = self.client.get(self.url.format(1), format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
