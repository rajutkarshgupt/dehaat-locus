import logging
from datetime import date

from rest_framework import serializers

from common.exceptions import BadRequestException
from common.utils import KhetiDB
from farmer_financing.models import DemographicDetails
from farmer_financing.serializers import UserApplicationSerializer
from repayment.models import TRANSACTION_TYPE_CHOICES, DemandSheet, Transaction
from repayment.utils import (
    get_current_demand_data_for_user,
    get_paid_emi_of_user,
    get_pending_emi_of_user,
)

LOGGER = logging.getLogger("stdout-logger")


class TransactionSerializer(serializers.ModelSerializer):
    payer = serializers.SerializerMethodField(read_only=True)

    def get_payer(self, instance):
        if instance.payer:
            return KhetiDB.get_record_for_given_table_and_id(
                "odoo_auth_user",
                instance.payer,
                "id, auth_id, full_name, email, phone_number",
            )
        return None

    def __validate_total_receipt_amount(self, attrs):
        if attrs.get("transaction_type") == TRANSACTION_TYPE_CHOICES.Deposit:
            meta = attrs.get("meta")
            total_deposit_amount = attrs.get("amount")
            total_deposit_receipt_amount = 0
            for deposit in meta:
                total_deposit_receipt_amount = (
                    total_deposit_receipt_amount + deposit.get("amount")
                )
            if float(total_deposit_receipt_amount) != float(total_deposit_amount):
                raise BadRequestException(
                    "Sum of receipt amounts must be equal to deposit amount"
                )

    def validate(self, attrs):
        self.__validate_total_receipt_amount(attrs)
        return attrs

    class Meta:
        model = Transaction
        fields = "__all__"


class FarmerListSerializer(serializers.Serializer):
    paid_emi = serializers.SerializerMethodField(read_only=True)
    pending_emi = serializers.SerializerMethodField(read_only=True)
    due_date = serializers.SerializerMethodField(read_only=True)
    net_demand = serializers.SerializerMethodField(read_only=True)
    tag = serializers.SerializerMethodField(read_only=True)

    def __get_photo_s3_path(self, user_id):
        user_data = KhetiDB.get_record_for_given_table_and_id(
            "odoo_auth_user", user_id, "data"
        )
        return user_data.get("photo_s3_path")

    def get_paid_emi(self, instance):
        user_id = instance.user
        return get_paid_emi_of_user(user_id)

    def get_pending_emi(self, instance):
        user_id = instance.user
        return get_pending_emi_of_user(user_id)

    def get_due_date(self, instance):
        user_id = instance.user
        demand_data = get_current_demand_data_for_user(user_id)
        if demand_data:
            return demand_data.due_date
        return None

    def get_net_demand(self, instance):
        user_id = instance.user
        demand_data = get_current_demand_data_for_user(user_id)
        if demand_data:
            return demand_data.net_demand_amount
        return 0

    def get_tag(self, instance):
        user_id = instance.user
        current_date = date.today()
        user_ids_with_due_date_passed = DemandSheet.objects.filter(
            to_date__gte=current_date,
            from_date__lte=current_date,
            due_date__lt=current_date,
            user_id=user_id,
        ).values_list("user_id", flat=True)
        if user_id in user_ids_with_due_date_passed:
            pending_emi = get_pending_emi_of_user(user_id)
            if float(pending_emi) > 0:
                return "overdue"
            return None
        return "to_be_collected"

    def to_representation(self, instance):
        farmer_list = super().to_representation(instance)
        application = UserApplicationSerializer(instance).data
        for key, value in application.items():
            if key not in ["id", "status"]:
                farmer_list[key] = value
        try:
            village, block, district, state = None, None, None, None
            farmer_list["user"]["photo_s3_path"] = self.__get_photo_s3_path(
                instance.user
            )
            demographic_details = DemographicDetails.objects.get(
                application_id=instance.id
            )
            village_id = demographic_details.village
            block_id = demographic_details.block
            district_id = demographic_details.district
            state_id = demographic_details.state
            if village_id:
                village = KhetiDB.get_record_for_given_table_and_id(
                    "common_village", village_id, "id, name"
                )
            if block_id:
                block = KhetiDB.get_record_for_given_table_and_id(
                    "common_block", block_id, "id, name"
                )
            if district_id:
                district = KhetiDB.get_record_for_given_table_and_id(
                    "common_district", district_id, "id, name"
                )
            if state_id:
                state = KhetiDB.get_record_for_given_table_and_id(
                    "common_state", state_id, "id, name"
                )
            farmer_list["village"] = village
            farmer_list["block"] = block
            farmer_list["district"] = district
            farmer_list["state"] = state
        except Exception as e:
            LOGGER.error(
                f"Error fetching location of user in repayment farmer list: {e}"
            )
            farmer_list["village"] = None
            farmer_list["block"] = None
            farmer_list["district"] = None
            farmer_list["state"] = None
        return farmer_list
