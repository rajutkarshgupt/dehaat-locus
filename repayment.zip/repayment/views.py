import json
import logging
from datetime import date

from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Sum
from django.http import HttpResponse
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly
from rest_framework.response import Response
from rest_framework.views import APIView

from common.constants import SaraloanCredConstants
from common.exceptions import BadRequestException
from common.external.aeros import Communication
from common.external.saraloan.saraloan import Saraloan
from common.utils import KhetiDB, retrieve_app_constant
from common.views import StandardResultsSetPageNumberPagination
from credit_line.model import Customer
from credit_line.utils import get_customer_with_number
from farmer_financing.models import DemographicDetails, UserApplication
from farmer_financing.permissions import LocusEndpointAccessPermission
from payment.model import Payment
from repayment.models import (
    ENTITY_TYPE_CHOICES,
    TRANSACTION_CHANNEL_CHOICES,
    TRANSACTION_TYPE_CHOICES,
    DemandSheet,
    Transaction,
)
from repayment.serializers import FarmerListSerializer, TransactionSerializer
from repayment.utils import get_paid_emi_of_user, get_pending_emi_of_user

LOGGER = logging.getLogger("stdout-logger")


class ListCreateTransactionView(generics.ListCreateAPIView):
    permission_classes = (LocusEndpointAccessPermission,)
    serializer_class = TransactionSerializer
    pagination_class = StandardResultsSetPageNumberPagination

    def perform_create(self, serializer, **kwargs):
        serializer.save(payer=kwargs.get("payer"))

    def post(self, request, *args, **kwargs):
        transaction_data = request.data
        data = dict()
        payer = None
        if (
            transaction_data.get("transaction_type")
            == TRANSACTION_TYPE_CHOICES.Collection
        ):
            extension_agent = self.request.agent_id
            data = dict(
                payee=extension_agent,
                payee_type=ENTITY_TYPE_CHOICES.FSFE,
                payer_type=ENTITY_TYPE_CHOICES.FARMER,
                amount=transaction_data.get("amount"),
                transaction_type=transaction_data.get("transaction_type"),
                transaction_channel=TRANSACTION_CHANNEL_CHOICES.Cash,
            )
            payer = transaction_data.get("farmer_id")

        if transaction_data.get("transaction_type") == TRANSACTION_TYPE_CHOICES.Deposit:
            payer = self.request.agent_id
            data = dict(
                payer_type=ENTITY_TYPE_CHOICES.FSFE,
                amount=transaction_data.get("amount"),
                transaction_type=transaction_data.get("transaction_type"),
                transaction_channel=transaction_data.get("transaction_channel"),
                meta=transaction_data.get("meta"),
            )

        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer, payer=payer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get_queryset(self):
        transactions = Transaction.objects.none()
        if (
            self.request.query_params.get("transaction_type")
            == TRANSACTION_TYPE_CHOICES.Collection
        ):
            extension_agent = self.request.agent_id
            transactions = Transaction.objects.filter(
                payee=extension_agent,
                transaction_type=TRANSACTION_TYPE_CHOICES.Collection,
            ).order_by("-created_at")
        elif (
            self.request.query_params.get("transaction_type")
            == TRANSACTION_TYPE_CHOICES.Deposit
        ):
            extension_agent = self.request.agent_id
            transactions = Transaction.objects.filter(
                payer=extension_agent, transaction_type=TRANSACTION_TYPE_CHOICES.Deposit
            ).order_by("-created_at")

        query_param_type = self.request.query_params.get("type", {})
        if query_param_type:
            query_param_type = json.loads(query_param_type)
            transaction_date_lte = query_param_type.get("transaction_date_lte")
            transaction_date_gte = query_param_type.get("transaction_date_gte")
            if transaction_date_gte and transaction_date_lte:
                transactions = transactions.filter(
                    created_at__date__lte=transaction_date_lte,
                    created_at__date__gte=transaction_date_gte,
                )

        return transactions


class RetrieveAggregatedAmountView(generics.RetrieveAPIView):
    permission_classes = (LocusEndpointAccessPermission,)

    def __get_aggregated_collection_amount_for_month(self, farmer_ids):
        total_collection_amount = 0
        for farmer_id in farmer_ids:
            try:
                paid_emi = get_paid_emi_of_user(farmer_id)
                total_collection_amount = total_collection_amount + float(paid_emi)
            except Exception as e:
                LOGGER.exception(
                    f"Error getting collection amount from farmer with id: {farmer_id}, Error: {e}"
                )
                continue
        return total_collection_amount

    def __get_aggregated_overdue_amount(self, current_date, farmer_ids):
        overdue_amount = 0
        user_ids_with_due_date_passed = DemandSheet.objects.filter(
            to_date__gte=current_date,
            from_date__lte=current_date,
            due_date__lt=current_date,
            user_id__in=farmer_ids,
        ).values_list("user_id", flat=True)
        for user_id in user_ids_with_due_date_passed:
            pending_emi = get_pending_emi_of_user(user_id)
            if float(pending_emi) > 0:
                overdue_amount = overdue_amount + float(pending_emi)
        return overdue_amount

    def __get_to_be_collected_and_surplus_amount(self, farmer_ids):
        to_be_collected = 0
        surplus = 0
        for farmer_id in farmer_ids:
            pending_emi = get_pending_emi_of_user(farmer_id)
            if pending_emi > 0:
                to_be_collected = to_be_collected + pending_emi
            else:
                surplus = surplus + abs(pending_emi)
        return to_be_collected, surplus

    def __get_overall_cash_in_hand(self, extension_agent):
        total_collection = (
            Transaction.objects.filter(
                payee=extension_agent,
                transaction_type=TRANSACTION_TYPE_CHOICES.Collection,
            )
            .aggregate(Sum("amount"))
            .get("amount__sum")
            or 0
        )
        total_deposit = (
            Transaction.objects.filter(
                payer=extension_agent,
                transaction_type=TRANSACTION_TYPE_CHOICES.Deposit,
            )
            .aggregate(Sum("amount"))
            .get("amount__sum")
            or 0
        )
        return float(total_collection) - float(total_deposit)

    def retrieve(self, request, *args, **kwargs):
        try:
            extension_agent = self.request.agent_id
            farmer_ids = UserApplication.objects.filter(
                extension_agent=extension_agent
            ).values_list("user", flat=True)
            current_date = date.today()
            current_demand_sheet_data = DemandSheet.objects.filter(
                to_date__gte=current_date,
                from_date__lte=current_date,
                user_id__in=farmer_ids,
            )
            if not current_demand_sheet_data:
                raise BadRequestException("No demand sheet found for this month")
            to_date = current_demand_sheet_data[0].to_date
            from_date = current_demand_sheet_data[0].from_date
            total_demand = current_demand_sheet_data.aggregate(
                Sum("net_demand_amount")
            ).get("net_demand_amount__sum")
            aggregated_collection_amount = (
                self.__get_aggregated_collection_amount_for_month(farmer_ids) or 0
            )
            aggregated_overdue_amount = (
                self.__get_aggregated_overdue_amount(current_date, farmer_ids) or 0
            )
            (
                aggregated_to_be_collected_amount,
                surplus_amount,
            ) = self.__get_to_be_collected_and_surplus_amount(farmer_ids) or (0, 0)
            cash_in_hand = self.__get_overall_cash_in_hand(extension_agent)
            data = dict(
                to_be_collected_amount=round(aggregated_to_be_collected_amount, 2),
                collected_amount=round(aggregated_collection_amount, 2),
                overdue_amount=round(aggregated_overdue_amount, 2),
                cash_in_hand=round(cash_in_hand, 2),
                total_demand=round(total_demand, 2),
                surplus_amount=round(surplus_amount, 2),
                to_date=to_date,
                from_date=from_date,
            )
            return Response(data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(f"Error: {e}", status=status.HTTP_400_BAD_REQUEST)


class ListFarmersView(generics.ListAPIView):
    permission_classes = (LocusEndpointAccessPermission,)
    serializer_class = FarmerListSerializer
    pagination_class = StandardResultsSetPageNumberPagination

    def __get_overdue_farmer_list(self, farmer_list):
        overdue_farmer_ids = []
        current_date = date.today()
        user_ids_with_due_date_passed = DemandSheet.objects.filter(
            to_date__gte=current_date,
            from_date__lte=current_date,
            due_date__lt=current_date,
            user_id__in=farmer_list,
        ).values_list("user_id", flat=True)
        for user_id in user_ids_with_due_date_passed:
            pending_emi = get_pending_emi_of_user(user_id)
            if float(pending_emi) > 0:
                overdue_farmer_ids.append(user_id)
        return overdue_farmer_ids

    def __get_to_be_collected_farmer_list(self, farmer_list):
        to_be_collected_farmer_list = []
        overdue_farmer_ids = self.__get_overdue_farmer_list(farmer_list)
        non_overdue_farmers = list(set(farmer_list) - set(overdue_farmer_ids))
        pending_emi_farmer_ids = []
        for farmer_id in non_overdue_farmers:
            try:
                pending_emi = get_pending_emi_of_user(farmer_id)
                if float(pending_emi) > 0:
                    pending_emi_farmer_ids.append(farmer_id)
            except Exception as e:
                LOGGER.info(f"Error getting to be collected farmer list, {e}")
        to_be_collected_farmer_list.extend(overdue_farmer_ids)
        to_be_collected_farmer_list.extend(pending_emi_farmer_ids)
        return list(set(to_be_collected_farmer_list))

    def __filter_farmers_with_due_date(self, due_date_lte, due_date_gte, farmer_list):
        user_ids_with_due_date_filter = DemandSheet.objects.filter(
            due_date__lte=due_date_lte,
            due_date__gte=due_date_gte,
            user_id__in=farmer_list,
        ).values_list("user_id", flat=True)
        return user_ids_with_due_date_filter

    def __create_response(self, queryset):
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            data = sorted(serializer.data, key=lambda k: k["pending_emi"], reverse=True)
            return self.get_paginated_response(data)
        serializer = self.get_serializer(queryset, many=True)
        data = sorted(serializer.data, key=lambda k: k["pending_emi"], reverse=True)
        return Response(data, status=status.HTTP_200_OK)

    def list(self, request, *args, **kwargs):
        list_type = request.query_params.get("list_type")
        filters = request.query_params.get("type")
        keyword = request.query_params.get("keyword")
        extension_agent = self.request.agent_id
        applications = UserApplication.objects.filter(extension_agent=extension_agent)
        farmer_list = applications.values_list("user", flat=True)
        dehaat_centers_ids = None
        block_ids = None
        group_leader_ids = None
        due_date_lte = None
        due_date_gte = None
        if filters:
            filters = json.loads(filters)
            dehaat_centers_ids = filters.get("dehaat_centers")
            block_ids = filters.get("location")
            group_leader_ids = filters.get("group_leader")
            due_date_lte = filters.get("due_date_lte")
            due_date_gte = filters.get("due_date_gte")

        if list_type:
            user_ids = []
            if list_type == "overdue":
                user_ids = self.__get_overdue_farmer_list(farmer_list)
            elif list_type == "to_be_collected":
                user_ids = self.__get_to_be_collected_farmer_list(farmer_list)
            applications = applications.filter(user__in=user_ids)

        if keyword:
            table_name = "odoo_auth_user"

            if keyword.isdigit():
                query = f"phone_number like '{keyword}%%'"
            else:
                query = f"full_name ilike '%%{keyword}%%'"

            user_details = KhetiDB.search_record_for_given_table_and_query(
                table_name, query
            )
            user_ids = [user["id"] for user in user_details]
            applications = applications.filter(user__in=user_ids)

        if dehaat_centers_ids:
            applications = applications.filter(dehaat_center__in=dehaat_centers_ids)
        if block_ids:
            application_ids = DemographicDetails.objects.filter(
                block__in=block_ids
            ).values_list("application_id", flat=True)
            applications = applications.filter(id__in=application_ids)
        if group_leader_ids:
            applications = applications.filter(group_leader__in=group_leader_ids)
        if due_date_lte and due_date_gte:
            user_ids = self.__filter_farmers_with_due_date(
                due_date_lte, due_date_gte, farmer_list
            )
            applications = applications.filter(user__in=user_ids)

        return self.__create_response(applications)


class RetrieveFarmerDetailsView(generics.RetrieveAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = FarmerListSerializer

    def get_object(self):
        farmer_id = self.kwargs.get("farmer_id")
        try:
            return UserApplication.objects.get(user=farmer_id)
        except ObjectDoesNotExist:
            raise BadRequestException(
                f"User Application with user_id: {farmer_id} does not exist."
            )


class GetLenderAndInterestRateView(generics.RetrieveAPIView):
    permission_classes = (LocusEndpointAccessPermission,)

    def get(self, *args, **kwargs):
        farmer_id = self.kwargs.get("farmer_id")
        extension_agent = self.request.agent_id
        try:
            application = UserApplication.objects.get(
                user=farmer_id, extension_agent=extension_agent
            )
            business_details = application.data.get("business_details")
            saraloan_applications = business_details.get("applications")
            if saraloan_applications:
                saraloan_application_id = saraloan_applications[0].get("id")
                application_details = Saraloan(
                    SaraloanCredConstants.FARMER
                ).get_application_details(saraloan_application_id)
                application.data["application_details"] = application_details
                application.save()
                monthly_interest_rate = None
                if application_details:
                    monthly_interest_rate = application_details.get(
                        "monthly_interest_rate"
                    )
                data = dict(
                    approved_interest_rate=monthly_interest_rate,
                    lender="BlackSoil",
                )
                return Response(data, status=status.HTTP_200_OK)
            else:
                LOGGER.info(
                    f"Saraloan application does not exist for user application id: {application.pk}"
                )
                data = dict(
                    approved_interest_rate=None,
                    lender="BlackSoil",
                )
                return Response(data, status=status.HTTP_200_OK)
        except ObjectDoesNotExist:
            raise BadRequestException(
                f"User application with user_id: {farmer_id} and extension agent: "
                f"{extension_agent} does not exist"
            )
        except Exception as e:
            LOGGER.exception(
                f"Exception in getting lender interest details, Error: {e}"
            )
            data = dict(
                approved_interest_rate=None,
                lender="BlackSoil",
            )
            return Response(data, status=status.HTTP_200_OK)


class IVRRepaymentOTPView(APIView):
    permission_classes = (IsAuthenticatedOrReadOnly,)

    def get(self, request, *args, **kwargs):
        phone_number = request.query_params.get("CallFrom")
        call_sid = request.query_params.get("CallSid")
        try:
            call_script = "There is some problem, Sorry for inconvenience"
            custom_field = request.query_params.get("CustomField")
            if phone_number and custom_field:
                custom_field = json.loads(custom_field)
                otp = custom_field.get("otp")
                repayment_amount = custom_field.get("amount")
                if otp:
                    otp_string = ", ".join(str(otp))
                    call_script = (
                        f"आपकी भुगतान राशि रु {repayment_amount} सफलतापूर्वक जमा करने "
                        f"के लिए, कृपया इस ओटीपी {otp_string} को देहात प्रतिनिधि या अपने "
                        f"नियुक्त किए गए ग्रुप लीडर के साथ साझा करें"
                    )
                    call_script = Communication.text_to_audio(call_script, 3600)
            return HttpResponse(
                call_script, status=status.HTTP_200_OK, content_type="text/plain"
            )
        except Exception as excp:
            LOGGER.exception(
                f"Exception : {excp}, in 'ivr repayment otp view', for call_sid: {call_sid}, "
                f"phone_number: {phone_number}"
            )


class IVRNextInstallmentStatus(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request, *args, **kwargs):
        phone_number = self.request.query_params.get("CallFrom", None)
        current_date = date.today()
        demand_sheet = (
            DemandSheet.objects.filter(
                from_date__lte=current_date, to_date__gte=current_date
            )
            .filter(phone_number=phone_number)
            .last()
        )
        if demand_sheet is None:
            return HttpResponse(
                retrieve_app_constant("IVR_NO_EMI_MESSAGE"),
                content_type="text/plain",
            )
        due_amount = demand_sheet.net_demand_amount
        due_date = demand_sheet.due_date
        call_script = f"आपकी {(due_amount)} रुपये की किश्त {due_date} को बक़ाया है "
        audio1 = Communication.text_to_audio(call_script, 3600)
        audio2 = retrieve_app_constant("IVR_NEXT_INSTALLMENT_MESSAGE")
        merged_audio = Communication.merge_two_audio(audio1, audio2)
        return HttpResponse(
            merged_audio,
            content_type="text/plain",
        )


class IVRRepaymentStatus(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request, *args, **kwargs):
        phone_number = self.request.query_params.get("CallFrom", None)
        try:
            customer = get_customer_with_number(phone_number)
            customer_credit_lines = customer.customer_credit_lines.all()
        except Customer.DoesNotExist:
            return HttpResponse(
                content_type="text/plain",
                status=status.HTTP_400_BAD_REQUEST,
            )
        result = Payment.objects.filter(
            customer_credit_line=customer_credit_lines[0]
        ).aggregate(total_repayment=Sum("payment_amount"))
        total_payment = result["total_repayment"]
        if total_payment is None:
            total_payment = 0

        call_script = f" {date.today()} तिथि तक,  आपके द्वारा भुगतान की गयी राशि {total_payment} रुपये है"
        audio1 = Communication.text_to_audio(call_script, 3600)
        audio2 = retrieve_app_constant("IVR_REPAYMENT_MESSAGE")
        merged_audio = Communication.merge_two_audio(audio1, audio2)
        return HttpResponse(
            merged_audio,
            content_type="text/plain",
        )
