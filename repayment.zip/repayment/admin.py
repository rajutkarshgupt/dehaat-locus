from django.contrib import admin

from base.admin import BaseAuditAdmin
from repayment.models import DemandSheet, DemandSheetUpload, Transaction


@admin.register(DemandSheetUpload)
class DemandSheetUploadAdmin(BaseAuditAdmin, admin.ModelAdmin):
    list_display = (
        "id",
        "from_date",
        "to_date",
        "upload_action",
        "file",
    )
    search_fields = ("id", "file")
    list_filter = ("to_date", "from_date")
    date_hierarchy = "created_at"


@admin.register(DemandSheet)
class DemandSheetAdmin(BaseAuditAdmin, admin.ModelAdmin):
    list_display = (
        "id",
        "to_date",
        "from_date",
        "due_date",
        "dpt",
        "user_id",
        "phone_number",
        "sanctioned_limit_amount",
        "disbursement_amount",
        "repaid_amount",
        "advance_paid_amount",
        "outstanding_amount",
        "cumulative_emi_amount",
        "principal_repayment_amount",
        "interest_repayment_amount",
        "processing_fee_repayment_amount",
        "overdue_amount",
        "late_fee_amount",
        "net_demand_amount",
    )
    search_fields = ("id", "user_id", "phone_number")
    list_filter = ("to_date", "from_date", "due_date")
    date_hierarchy = "created_at"


@admin.register(Transaction)
class TransactionAdmin(BaseAuditAdmin, admin.ModelAdmin):
    list_display = (
        "id",
        "transaction_id",
        "payee",
        "payer",
        "payee_type",
        "payer_type",
        "amount",
        "transaction_type",
        "transaction_channel",
        "meta",
    )
    search_fields = ("transaction_id", "id")
    list_filter = (
        "payee",
        "payer",
        "transaction_type",
        "transaction_channel",
        "payee_type",
        "payee_type",
    )
    date_hierarchy = "created_at"
