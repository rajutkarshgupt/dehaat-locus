from datetime import date, datetime

from celery import shared_task
from django.db import transaction

from common.utils import KhetiDB
from repayment.models import DemandSheet


@shared_task
def insert_demand_sheet_details(row, to_date, from_date):
    farmer_id = row[0]
    try:
        farmer_id = int(farmer_id)
        farmer_details = KhetiDB.get_record_for_given_table_and_id(
            "odoo_auth_user", int(farmer_id)
        )
        if not farmer_details:
            return f"Invalid farmer_id: {farmer_id} - does not exist."
    except Exception as e:
        return f"Invalid farmer_id: {farmer_id}, error: {e}"
    mobile_number = row[1]
    try:
        farmer_details = KhetiDB.search_record_for_given_table_and_query(
            "odoo_auth_user", f"phone_number='{mobile_number}'"
        )
        if not farmer_details:
            return f"Invalid farmer mobile number: {mobile_number} - does not exist."
    except Exception as e:
        return f"Invalid farmer mobile number: {mobile_number}, error: {e}"
    total_sanctioned_limit = row[2]
    total_disbursed_amount = row[3]
    total_repaid_amount = row[4]
    total_amount_paid_in_advance = row[5]
    total_outstanding = row[6]
    cumulative_emi = row[7]
    total_principal_repayment_due = row[8]
    total_interest_repayment_due = row[9]
    total_processing_fee_repayment_due = row[10]
    total_overdue_amount_repayment_due = row[11]
    total_late_fee_amount_due = row[12]
    net_demand = row[13]
    due_date = row[14]
    date_format = "%Y-%m-%d"
    try:
        due_date = datetime.strptime(due_date, date_format).date()
    except Exception as e:
        return f"Invalid due date: {due_date}, correct format id YYYY-MM-DD, Error: {e}"
    try:
        to_from_date_format = "%Y-%m-%dT%H:%M:%S"
        to_date = datetime.strptime(to_date, to_from_date_format).date()
        from_date = datetime.strptime(from_date, to_from_date_format).date()
    except Exception as e:
        return (
            f"Invalid to_date: {to_date} or from_date: {from_date}, correct format id YYYY-MM-DD, "
            f"Error: {e}"
        )
    with transaction.atomic():
        try:
            DemandSheet.objects.create(
                to_date=to_date,
                from_date=from_date,
                due_date=due_date,
                user_id=farmer_id,
                phone_number=mobile_number,
                sanctioned_limit_amount=total_sanctioned_limit,
                disbursement_amount=total_disbursed_amount,
                repaid_amount=total_repaid_amount,
                advance_paid_amount=total_amount_paid_in_advance,
                outstanding_amount=total_outstanding,
                cumulative_emi_amount=cumulative_emi,
                principal_repayment_amount=total_principal_repayment_due,
                interest_repayment_amount=total_interest_repayment_due,
                processing_fee_repayment_amount=total_processing_fee_repayment_due,
                overdue_amount=total_overdue_amount_repayment_due,
                late_fee_amount=total_late_fee_amount_due,
                net_demand_amount=net_demand,
            )
        except Exception as e:
            return f"Invalid demand sheet row {row}, error: {e}"
    return f"Successfully Added Demand Sheet row: {row}"


@shared_task
def update_previous_demand_details(row, to_date, from_date):
    farmer_id = row[0]
    try:
        farmer_id = int(farmer_id)
        farmer_details = KhetiDB.get_record_for_given_table_and_id(
            "odoo_auth_user", int(farmer_id)
        )
        if not farmer_details:
            return f"Invalid farmer_id: {farmer_id} - does not exist."
    except Exception as e:
        return f"Invalid farmer_id: {farmer_id}, error: {e}"
    mobile_number = row[1]
    try:
        farmer_details = KhetiDB.search_record_for_given_table_and_query(
            "odoo_auth_user", f"phone_number='{mobile_number}'"
        )
        if not farmer_details:
            return f"Invalid farmer mobile number: {mobile_number} - does not exist."
    except Exception as e:
        return f"Invalid farmer mobile number: {mobile_number}, error: {e}"
    total_sanctioned_limit = row[2]
    total_disbursed_amount = row[3]
    total_repaid_amount = row[4]
    total_amount_paid_in_advance = row[5]
    total_outstanding = row[6]
    cumulative_emi = row[7]
    total_principal_repayment_due = row[8]
    total_interest_repayment_due = row[9]
    total_processing_fee_repayment_due = row[10]
    total_overdue_amount_repayment_due = row[11]
    total_late_fee_amount_due = row[12]
    net_demand = row[13]
    due_date = row[14]
    date_format = "%Y-%m-%d"
    try:
        due_date = datetime.strptime(due_date, date_format).date()
    except Exception as e:
        return f"Invalid due date: {due_date}, correct format id YYYY-MM-DD, Error: {e}"
    try:
        to_from_date_format = "%Y-%m-%dT%H:%M:%S"
        to_date = datetime.strptime(to_date, to_from_date_format).date()
        from_date = datetime.strptime(from_date, to_from_date_format).date()
    except Exception as e:
        return (
            f"Invalid to_date: {to_date} or from_date: {from_date}, correct format id YYYY-MM-DD, "
            f"Error: {e}"
        )
    current_date = date.today()
    with transaction.atomic():
        try:
            demand_sheet = DemandSheet.objects.filter(
                to_date__gte=current_date,
                user_id=farmer_id,
            ).order_by("-to_date")[0]
            demand_sheet.to_date = to_date
            demand_sheet.from_date = from_date
            demand_sheet.due_date = due_date
            demand_sheet.phone_number = mobile_number
            demand_sheet.sanctioned_limit_amount = total_sanctioned_limit
            demand_sheet.disbursement_amount = total_disbursed_amount
            demand_sheet.repaid_amount = total_repaid_amount
            demand_sheet.advance_paid_amount = total_amount_paid_in_advance
            demand_sheet.outstanding_amount = total_outstanding
            demand_sheet.cumulative_emi_amount = cumulative_emi
            demand_sheet.principal_repayment_amount = total_principal_repayment_due
            demand_sheet.interest_repayment_amount = total_interest_repayment_due
            demand_sheet.processing_fee_repayment_amount = (
                total_processing_fee_repayment_due
            )
            demand_sheet.overdue_amount = total_overdue_amount_repayment_due
            demand_sheet.late_fee_amount = total_late_fee_amount_due
            demand_sheet.net_demand_amount = net_demand
            demand_sheet.save()
        except Exception as e:
            return f"Invalid demand sheet row {row}, error: {e}"
    return f"Successfully Updated Demand Sheet with row: {row}"
